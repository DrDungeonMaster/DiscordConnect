# 1.1.0 -- Forked by DrDungeonMaster
Added support for Polyglot module. Optionally hides text in languages other than Common with spoiler-text.

# 1.0.5
Fixed messages from tokens with images from an external URL not properly being sent to discord.
Added option for whether it should put quotes around chat messages!
Suppressed "Big Spell description goes here" messages. Nobody needs that kind of spam!

# 1.0.4
Reconfigured the splitting feature to allow users to completely ignore rolls or standard chat just by choosing which hooks to add to the config.

# 1.0.3
Added a basic feature to allow splitting rolls and chat messages into two different discord channels, using multiple webhooks.

# 1.0.2
Added a feature to allow users to block private messages/rolls from being copied to discord.

# 1.0.1
Added a feature to allow a "main GM" to be specified, as a simple way of preventing unwanted duplication of messages due to multiple GMs in a session.

# 1.0.0
Initial release
